import '../../widgets/offline_query_banner.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import '../../core/theme/design_tokens.dart';
import '../../core/network/api_client.dart';
import '../../models/gasto_model.dart';
import '../../models/categoria_model.dart';
import '../../models/dependiente_model.dart';
import '../../services/gastos_service.dart';


class AgregarGastoScreen extends StatefulWidget {
  final GastoModel? gastoParaEditar;
  const AgregarGastoScreen({super.key, this.gastoParaEditar});

  @override
  State<AgregarGastoScreen> createState() => _AgregarGastoScreenState();
}

class _AgregarGastoScreenState extends State<AgregarGastoScreen> {
  final TextEditingController _montoController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  DateTime _fecha = DateTime.now();
  int? _idCategoria;
  int? _idDependiente;

  List<CategoriaModel> _listaCategorias = [];
  List<DependienteModel> _listaDependientes = [];
  bool _isLoadingData = true;
  bool _isSaving = false;
  bool _showScrollIndicator = false;
  final ScrollController _categoryScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  void _loadInitialData() async {
    List<CategoriaModel> cats = [];
    try {
      cats = await GastosService.obtenerCategorias();
    } catch (_) {/* El aviso muestra el fallo del catálogo. */}
    List<DependienteModel> deps = [];
    try {
      deps = await GastosService.obtenerDependientes();
    } catch (_) {/* El aviso muestra el fallo del catálogo. */}

    if (mounted) {
      setState(() {
        _listaCategorias = cats.where((c) => c.activa).toList();
        _listaDependientes = deps;
        _isLoadingData = false;

        if (widget.gastoParaEditar != null) {
          final g = widget.gastoParaEditar!;
          _montoController.text = g.monto <= 0 ? '' : g.monto % 1 == 0
              ? g.monto.toStringAsFixed(0)
              : g.monto.toStringAsFixed(2).replaceAll('.', ',');
          _descriptionController.text = g.descripcion ?? '';
          _fecha = g.fecha;
          _idDependiente = g.idDependientes;

          if (g.idCategoria != null) {
            // Gasto real que se está editando: el id ya es válido.
            _idCategoria = g.idCategoria;
          } else if (g.categoriaNombre != null) {
            // Viene de un parser de voz/QR: solo detectó el NOMBRE de
            // la categoría, no el id real. Intentamos encontrar una
            // categoría real del backend con ese mismo nombre; si no
            // hay coincidencia, queda sin seleccionar y el usuario la
            // elige a mano.
            final sugerida = _listaCategorias.where(
                  (c) => c.nombre.toLowerCase() == g.categoriaNombre!.toLowerCase(),
            );
            if (sugerida.isNotEmpty) {
              _idCategoria = sugerida.first.id;
            }
          }
        } else if (_listaDependientes.isNotEmpty) {
          _idDependiente = _listaDependientes.first.id;
        }
      });
    }
  }

  @override
  void dispose() {
    _montoController.dispose();
    _descriptionController.dispose();
    _categoryScrollController.dispose();
    super.dispose();
  }

  CategoriaModel? get _categoriaSeleccionada {
    if (_idCategoria == null) return null;
    try {
      return _listaCategorias.firstWhere((c) => c.id == _idCategoria);
    } catch (_) {
      return null;
    }
  }

  DependienteModel? get _dependienteSeleccionado {
    if (_idDependiente == null) return null;
    try {
      return _listaDependientes.firstWhere((d) => d.id == _idDependiente);
    } catch (_) {
      return null;
    }
  }

  String _formatFecha(DateTime date) {
    final dd = date.day.toString().padLeft(2, '0');
    final mm = date.month.toString().padLeft(2, '0');
    return '$dd/$mm/${date.year}';
  }

  Future<void> _showNeumorphicSheet(Widget sheet) {
    return showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Cerrar',
      barrierColor: Colors.transparent,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return AnimatedBuilder(
          animation: animation,
          builder: (context, _) {
            final t = Curves.easeOut.transform(animation.value);
            return Stack(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(color: Colors.black.withValues(alpha: 0.4 * t)),
                ),
                Positioned.fill(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 8 * t, sigmaY: 8 * t),
                    child: const SizedBox.expand(),
                  ),
                ),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: FractionalTranslation(
                    translation: Offset(0, 1 - t),
                    child: Material(type: MaterialType.transparency, child: sheet),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _showCalendarSheet() async {
    final today = DateTime.now();
    final first = DateTime(1900);
    final last = DateTime(today.year, today.month, today.day);
    final initial = _fecha.isBefore(first)
        ? first
        : (_fecha.isAfter(last) ? last : _fecha);
    final selected = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: last,
      helpText: 'Corregir fecha del gasto',
    );
    if (selected != null && mounted) setState(() => _fecha = selected);
  }
  void _showCategorySheet() => _showNeumorphicSheet(_buildCategorySheet());
  void _showDependentSheet() => _showNeumorphicSheet(_buildDependentSheet());

  void _crearGasto() async {
    if (_isSaving) return;
    String montoStr = _montoController.text.replaceAll('\$', '');
    if (montoStr.contains(',')) {
      montoStr = montoStr.replaceAll('.', '').replaceAll(',', '.');
    } else {
      montoStr = montoStr.replaceAll('.', '');
    }

    final monto = double.tryParse(montoStr) ?? 0.0;
    if (monto <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Por favor, ingresa un monto válido')));
      return;
    }

    setState(() => _isSaving = true);
    final cat = _categoriaSeleccionada;
    final dep = _dependienteSeleccionado;

    final gasto = GastoModel(
      id: widget.gastoParaEditar?.id,
      idCategoria: cat?.id,
      idDependientes: dep?.id,
      descripcion: _descriptionController.text.isEmpty ? null : _descriptionController.text,
      monto: monto,
      fecha: _fecha,
    );

    try {
      if (gasto.id == null) {
        await GastosService.crearGasto(gasto);
      } else {
        await GastosService.actualizarGasto(gasto.id!, gasto);
      }

      if (!mounted) return;
      setState(() => _isSaving = false);

      if (gasto.id == null) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Guardado en el teléfono. Pendiente de sincronizar.')));
      Navigator.pop(context, true);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _isSaving = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoadingData) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(color: AppColors.accent)),
      );
    }
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              OfflineQueryBanner(
                  resource: '/categorias', onRetry: _loadInitialData),
              OfflineQueryBanner(
                  resource: '/dependientes', onRetry: _loadInitialData),
              const SizedBox(height: 20),
              _buildHeader(),
              const SizedBox(height: 26),
              _buildFormCard(),
              const SizedBox(height: 28),
              _buildCrearButton(),
              const SizedBox(height: 12),
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    'Ahorrapp puede cometer errores. Verifica siempre la información antes de guardar.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.error, fontSize: 10, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _buildCancelarButton(),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        _NeumorphicIcon(icon: Icons.arrow_back, size: 20, onTap: () => Navigator.pop(context)),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.gastoParaEditar?.id != null ? 'Editar gasto' : 'Agregar gasto',
              style: const TextStyle(color: AppColors.textPrimary, fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 2),
            Text(
              widget.gastoParaEditar?.id != null ? 'Modificar registro' : 'Registro manual',
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildFormCard() {
    return _NeumorphicContainer(
      borderRadius: 24,
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget.gastoParaEditar != null && widget.gastoParaEditar!.id == null) ...[
            const Text(
              'Revisa el monto, la fecha y la descripción antes de guardar. Si no se pudo reconocer una fecha válida, se propone la fecha de hoy.',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
            const SizedBox(height: 16),
          ],
          _buildLabel('Monto', required: true),
          const SizedBox(height: 8),
          _buildTextField(controller: _montoController, hint: '\$0', keyboardType: const TextInputType.numberWithOptions(decimal: true)),
          const SizedBox(height: 18),
          _buildLabel('Descripción'),
          const SizedBox(height: 8),
          _buildTextField(controller: _descriptionController, hint: 'Ej: Almuerzo de trabajo'),
          const SizedBox(height: 18),
          _buildLabel('Fecha de registro', required: true),
          const SizedBox(height: 8),
          _buildFechaField(),
          const SizedBox(height: 18),
          _buildLabel('Categoría'),
          const SizedBox(height: 8),
          _buildCategoriaField(),
          const SizedBox(height: 18),
          _buildLabel('Dependiente'),
          const SizedBox(height: 8),
          _buildDependienteField(),
        ],
      ),
    );
  }

  Widget _buildLabel(String text, {bool required = false}) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(text: text, style: const TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
          if (required)
            const TextSpan(text: ' *', style: TextStyle(color: AppColors.error, fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _buildInsetBox({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.inset,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black.withValues(alpha: 0.35)),
      ),
      child: child,
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String hint, TextInputType keyboardType = TextInputType.text}) {
    return _buildInsetBox(
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        style: const TextStyle(color: AppColors.textPrimary, fontSize: 15),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildFechaField() {
    return _buildInsetBox(
      child: InkWell(
        onTap: _showCalendarSheet,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              const Icon(Icons.calendar_month, color: Color(0xFF4ADE80), size: 20),
              const SizedBox(width: 10),
              Text(_formatFecha(_fecha), style: const TextStyle(color: AppColors.textPrimary, fontSize: 14)),
              const Spacer(),
              const Icon(Icons.expand_more, color: AppColors.textSecondary, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoriaField() {
    final cat = _categoriaSeleccionada;
    return _buildInsetBox(
      child: InkWell(
        onTap: _showCategorySheet,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              if (cat != null) ...[
                Icon(_getIconForCategory(cat.nombre), color: _getColorForCategory(cat.nombre), size: 20),
                const SizedBox(width: 10),
                Expanded(child: Text(cat.nombre, style: const TextStyle(color: AppColors.textPrimary, fontSize: 14))),
              ] else
                const Expanded(child: Text('Sin seleccionar', style: TextStyle(color: AppColors.textSecondary, fontSize: 14))),
              const Icon(Icons.expand_more, color: AppColors.textSecondary, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDependienteField() {
    final dep = _dependienteSeleccionado;
    return _buildInsetBox(
      child: InkWell(
        onTap: _showDependentSheet,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              const Icon(Icons.person, color: Color(0xFF60A5FA), size: 20),
              const SizedBox(width: 10),
              Expanded(child: Text(dep?.nombre ?? 'Sin seleccionar', style: const TextStyle(color: AppColors.textPrimary, fontSize: 14))),
              const Icon(Icons.expand_more, color: AppColors.textSecondary, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategorySheet() {
    return StatefulBuilder(
      builder: (context, setSheetState) {
        return Container(
          decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.navInactive, borderRadius: BorderRadius.circular(2)))),
                const SizedBox(height: 16),
                const Text('Seleccionar categoría', style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    ConstrainedBox(
                      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.55),
                      child: NotificationListener<ScrollNotification>(
                        onNotification: (scroll) {
                          if (scroll.metrics.extentAfter > 10) {
                            if (!_showScrollIndicator) setSheetState(() => _showScrollIndicator = true);
                          } else {
                            if (_showScrollIndicator) setSheetState(() => _showScrollIndicator = false);
                          }
                          return false;
                        },
                        child: ListView.separated(
                          controller: _categoryScrollController,
                          shrinkWrap: true,
                          itemCount: _listaCategorias.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 12),
                          itemBuilder: (context, index) {
                            // Verificación inicial de scroll al construir
                            WidgetsBinding.instance.addPostFrameCallback((_) {
                              if (_categoryScrollController.hasClients) {
                                final hasMore = _categoryScrollController.position.extentAfter > 10;
                                if (hasMore != _showScrollIndicator) {
                                  setSheetState(() => _showScrollIndicator = hasMore);
                                }
                              }
                            });
                            return _buildCategoryCard(_listaCategorias[index]);
                          },
                        ),
                      ),
                    ),
                    if (_showScrollIndicator)
                      Positioned(
                        bottom: 0,
                        child: _ArrowIndicator(),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        );
      }
    );
  }

  Widget _buildCategoryCard(CategoriaModel cat) {
    final isSelected = _idCategoria == cat.id;
    final icon = _getIconForCategory(cat.nombre);
    final color = _getColorForCategory(cat.nombre);
    return GestureDetector(
      onTap: () { setState(() => _idCategoria = cat.id); Navigator.pop(context); },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(18),
          border: isSelected ? Border.all(color: AppColors.accent.withValues(alpha: 0.6), width: 1.5) : null,
          boxShadow: const [BoxShadow(color: Color(0xFF05060D), offset: Offset(3, 3), blurRadius: 8)],
        ),
        child: Row(
          children: [
            Container(width: 44, height: 44, decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: color, size: 22)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(cat.nombre, style: const TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w600)),
                  if (cat.descripcion != null) Text(cat.descripcion!, style: const TextStyle(color: AppColors.textSecondary, fontSize: 11), maxLines: 1),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDependentSheet() {
    return Container(
      decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.navInactive, borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 16),
            const Text('Seleccionar dependiente', style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ListView.separated(
              shrinkWrap: true,
              itemCount: _listaDependientes.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) => _buildDependentCard(_listaDependientes[index]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDependentCard(DependienteModel dep) {
    final isSelected = _idDependiente == dep.id;
    return GestureDetector(
      onTap: () { setState(() => _idDependiente = dep.id); Navigator.pop(context); },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(18),
          border: isSelected ? Border.all(color: AppColors.accent.withValues(alpha: 0.6), width: 1.5) : null,
          boxShadow: const [BoxShadow(color: Color(0xFF05060D), offset: Offset(3, 3), blurRadius: 8)],
        ),
        child: Row(
          children: [
            Container(width: 44, height: 44, decoration: const BoxDecoration(color: Color(0xFF60A5FA), shape: BoxShape.circle), child: const Icon(Icons.person, color: Colors.white, size: 22)),
            const SizedBox(width: 14),
            Text(dep.nombre, style: const TextStyle(color: AppColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildCrearButton() {
    return GestureDetector(
      onTap: _isSaving ? null : _crearGasto,
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFF8C00)]),
          borderRadius: BorderRadius.circular(28),
          boxShadow: [BoxShadow(color: AppColors.accent.withValues(alpha: 0.4), blurRadius: 20)],
        ),
        child: Center(
          child: _isSaving
              ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
              : Text(widget.gastoParaEditar?.id != null ? 'Guardar cambios' : 'Crear gasto', style: const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _buildCancelarButton() {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(26)),
        child: const Center(child: Text('Cancelar', style: TextStyle(color: AppColors.textSecondary, fontSize: 14, fontWeight: FontWeight.w600))),
      ),
    );
  }

  IconData _getIconForCategory(String nombre) {
    switch (nombre) {
      case 'Alimentación': return Icons.restaurant;
      case 'Transporte': return Icons.directions_bus;
      case 'Salud': return Icons.medical_services;
      case 'Educación': return Icons.school;
      case 'Entretenimiento': return Icons.movie;
      case 'Servicios': return Icons.home;
      default: return Icons.shopping_cart;
    }
  }

  Color _getColorForCategory(String nombre) {
    switch (nombre) {
      case 'Alimentación': return const Color(0xFFA8A2FF);
      case 'Transporte': return const Color(0xFF60A5FA);
      case 'Salud': return const Color(0xFFFF6B6B);
      case 'Educación': return const Color(0xFF4ADE80);
      case 'Entretenimiento': return const Color(0xFFC084FC);
      case 'Servicios': return const Color(0xFFFF8C4A);
      default: return AppColors.accent;
    }
  }
}

class _ArrowIndicator extends StatefulWidget {
  @override
  State<_ArrowIndicator> createState() => _ArrowIndicatorState();
}

class _ArrowIndicatorState extends State<_ArrowIndicator> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))..repeat(reverse: true);
    _animation = Tween<double>(begin: 0, end: 8).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _animation.value),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: AppColors.surface.withValues(alpha: 0.8),
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 4)],
            ),
            child: const Icon(Icons.keyboard_arrow_down, color: AppColors.accent, size: 24),
          ),
        );
      },
    );
  }
}

class _NeumorphicContainer extends StatelessWidget {
  final Widget child;
  final double borderRadius;
  final EdgeInsets padding;
  const _NeumorphicContainer({required this.child, this.borderRadius = 16, this.padding = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(borderRadius), boxShadow: const [BoxShadow(color: Color(0xFF05060D), offset: Offset(4, 4), blurRadius: 12)]),
      child: child,
    );
  }
}

class _NeumorphicIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final VoidCallback onTap;
  const _NeumorphicIcon({required this.icon, required this.size, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40, height: 40,
        decoration: const BoxDecoration(color: AppColors.background, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Color(0xFF05060D), offset: Offset(3, 3), blurRadius: 8)]),
        child: Icon(icon, color: AppColors.textSecondary, size: size),
      ),
    );
  }
}
