import 'package:flutter/foundation.dart';
import '../core/network/api_client.dart';
import '../models/ingreso_model.dart';
import '../models/categoria_model.dart';
import 'auth_service.dart';

class IngresosService {
  @visibleForTesting
  static ApiClient client = ApiClient();

  /// Crea un ingreso nuevo (POST /movimientos).
  /// Devuelve el id generado (id_ingresos) para que la pantalla pueda
  /// armar el IngresoModel completo localmente.
  static Future<int> crearIngreso(IngresoModel ingreso) async {
    final token = await AuthService.instance.getToken();

    final respuesta = await client.post(
      '/movimientos',
      token: token,
      body: {
        'tipo_flujo': 'Entrada',
        'subtipo_modulo': 'Ingreso',
        'datos': ingreso.toRequestBody(),
      },
    );

    return respuesta['ID_detalle'] as int;
  }

  /// Actualiza un ingreso existente (PUT /movimientos/ingresos/:id).
  static Future<void> actualizarIngreso(int id, IngresoModel ingreso) async {
    final token = await AuthService.instance.getToken();

    await client.put(
      '/movimientos/ingresos/$id',
      token: token,
      body: ingreso.toRequestBody(),
    );
  }

  /// Trae la lista de ingresos del usuario (GET /movimientos/ingresos).
  static Future<List<IngresoModel>> obtenerIngresos() async {
    try {
      final token = await AuthService.instance.getToken();
      final data = await client.getList('/movimientos/ingresos', token: token);

      return data
          .map((json) => IngresoModel.fromJson(json as Map<String, dynamic>))
          .toList();
    } catch (_) {
      // Si falla, la pantalla simplemente muestra la lista vacía.
      return [];
    }
  }

  /// Elimina un ingreso (DELETE /movimientos/ingresos/:id).
  /// Devuelve true si se eliminó correctamente.
  static Future<bool> eliminarIngreso(int id) async {
    try {
      final token = await AuthService.instance.getToken();
      await client.delete('/movimientos/ingresos/$id', token: token);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Trae las categorías disponibles (GET /categorias).
  static Future<List<CategoriaModel>> obtenerCategorias() async {
    try {
      final token = await AuthService.instance.getToken();
      final respuesta = await client.get('/categorias', token: token);

      final List categorias = respuesta['categorias'] ?? [];
      return categorias
          .map((json) => CategoriaModel.fromJson(json as Map<String, dynamic>))
          .toList();
    } catch (_) {
      // Si falla, la pantalla simplemente no muestra categorías y el
      // usuario puede guardar el ingreso sin categoría.
      return [];
    }
  }
}
