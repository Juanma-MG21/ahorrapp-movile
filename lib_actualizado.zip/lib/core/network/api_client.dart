import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

/// Excepción lanzada cuando el backend responde { ok: false, mensaje }
/// o cuando hay un problema de red/formato de respuesta.
class ApiException implements Exception {
  ApiException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

/// Cliente HTTP genérico para hablar con el backend de AhorrApp.
/// Centraliza URL base, headers y parseo/errores comunes, para que
/// los servicios (AuthService, GastosService, etc.) no repitan lógica.
class ApiClient {
  const ApiClient({String? baseUrl}) : baseUrl = baseUrl ?? _defaultBaseUrl;

  static const String _defaultBaseUrl =
      'https://ahorrapp-react-pkj9.onrender.com/api';

  final String baseUrl;

  /// Arma la URI final a partir de [baseUrl] y [path], evitando problemas
  /// si [baseUrl] termina en '/' o si [path] ya trae un prefijo '/api/'
  /// duplicado.
  Uri _uri(String path) {
    final normalizedBase = baseUrl.endsWith('/')
        ? baseUrl.substring(0, baseUrl.length - 1)
        : baseUrl;
    final normalizedPath = path.startsWith('/') ? path : '/$path';
    final apiPath = normalizedPath.startsWith('/api/')
        ? normalizedPath.substring(4)
        : normalizedPath;
    return Uri.parse('$normalizedBase$apiPath');
  }

  Map<String, String> _headers({String? token}) {
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // ============================================================
  // MÉTODOS GENÉRICOS (esperan respuesta { ok, ... } del backend)
  // ============================================================

  /// POST genérico. [path] empieza con '/', ej: '/auth/login'.
  Future<Map<String, dynamic>> post(
    String path, {
    Map<String, dynamic>? body,
    String? token,
  }) {
    return _send(
      () => http.post(
        _uri(path),
        headers: _headers(token: token),
        body: jsonEncode(body ?? {}),
      ),
    );
  }

  /// GET genérico. Para endpoints que responden { ok, ... }.
  Future<Map<String, dynamic>> get(String path, {String? token}) {
    return _send(() => http.get(_uri(path), headers: _headers(token: token)));
  }

  /// PUT genérico.
  Future<Map<String, dynamic>> put(
    String path, {
    Map<String, dynamic>? body,
    String? token,
  }) {
    return _send(
      () => http.put(
        _uri(path),
        headers: _headers(token: token),
        body: jsonEncode(body ?? {}),
      ),
    );
  }

  /// DELETE genérico. Para endpoints que responden { ok, ... }.
  Future<Map<String, dynamic>> delete(String path, {String? token}) {
    return _send(
      () => http.delete(_uri(path), headers: _headers(token: token)),
    );
  }

  /// PATCH genérico.
  Future<Map<String, dynamic>> patch(
    String path, {
    Map<String, dynamic>? body,
    String? token,
  }) {
    return _send(
      () => http.patch(
        _uri(path),
        headers: _headers(token: token),
        body: jsonEncode(body ?? {}),
      ),
    );
  }

  // ============================================================
  // GET PARA RESPUESTAS DE TIPO LISTA
  // ============================================================

  /// GET para endpoints que responden un array plano en vez de { ok, ... },
  /// como GET /movimientos/ingresos.
  Future<List<dynamic>> getList(String path, {String? token}) async {
    late final http.Response response;

    try {
      response = await http.get(_uri(path), headers: _headers(token: token));
    } catch (_) {
      throw ApiException(
        'No se pudo conectar con el servidor. Revisa tu conexión.',
      );
    }

    if (response.statusCode >= 400) {
      // Estos endpoints, cuando fallan, sí devuelven { ok: false, mensaje }.
      try {
        final decoded = jsonDecode(response.body) as Map<String, dynamic>;
        throw ApiException(
          decoded['mensaje'] as String? ??
              decoded['message'] as String? ??
              'Error del servidor',
          statusCode: response.statusCode,
        );
      } on ApiException {
        rethrow;
      } catch (_) {
        throw ApiException(
          'Ocurrió un error inesperado (código ${response.statusCode})',
          statusCode: response.statusCode,
        );
      }
    }

    try {
      return jsonDecode(response.body) as List<dynamic>;
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException(
        'Respuesta inesperada del servidor (formato inválido: $e)',
        statusCode: response.statusCode,
      );
    }
  }

  // ============================================================
  // POST "CRUDO" — no asume { ok, ... }
  // ============================================================

  /// POST que NO espera el formato { ok, ... } del backend.
  /// Se usa, por ejemplo, para flujos de auth con Google donde
  /// el backend devuelve directamente { token, usuario } u otro shape.
  /// Acepta [token] igual que el resto del cliente, y [headers] extra
  /// por si algún flujo puntual necesita un encabezado adicional.
  Future<Map<String, dynamic>> postRaw(
    String path, {
    Object? body,
    String? token,
    Map<String, String>? headers,
  }) async {
    late final http.Response response;

    try {
      response = await http
          .post(
            _uri(path),
            headers: {
              ..._headers(token: token),
              ...?headers,
            },
            body: body == null ? null : jsonEncode(body),
          )
          .timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw ApiException(
        'El servidor está tardando demasiado en responder. Puede estar iniciándose; inténtalo de nuevo en unos segundos.',
      );
    } catch (e) {
      throw ApiException(
        'No se pudo conectar con el servidor ($e). Revisa tu conexión.',
      );
    }

    Map<String, dynamic> decoded;
    try {
      decoded = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (e) {
      throw ApiException(
        'Respuesta del servidor no es JSON válido (posible error 404 o 500 HTML). Detalles: $e',
        statusCode: response.statusCode,
      );
    }

    if (response.statusCode >= 400) {
      final mensaje = decoded['mensaje'] as String? ??
          decoded['message'] as String? ??
          'Ocurrió un error inesperado (código ${response.statusCode})';
      throw ApiException(mensaje, statusCode: response.statusCode);
    }

    return decoded;
  }

  // ============================================================
  // ENVÍO INTERNO CON TIMEOUT Y PARSEO ESTÁNDAR
  // ============================================================

  Future<Map<String, dynamic>> _send(
    Future<http.Response> Function() request,
  ) async {
    late final http.Response response;

    try {
      response = await request().timeout(const Duration(seconds: 45));
    } on TimeoutException {
      throw ApiException(
        'El servidor está tardando demasiado en responder. Puede estar iniciándose; inténtalo de nuevo en unos segundos.',
      );
    } catch (e) {
      throw ApiException(
        'No se pudo conectar con el servidor ($e). Revisa tu conexión.',
      );
    }

    Map<String, dynamic> decoded;
    try {
      decoded = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (e) {
      throw ApiException(
        'Respuesta del servidor no es JSON válido (posible error 404 o 500 HTML). Detalles: $e',
        statusCode: response.statusCode,
      );
    }

    final bool ok = decoded['ok'] == true;

    if (!ok || response.statusCode >= 400) {
      final mensaje = decoded['mensaje'] as String? ??
          decoded['message'] as String? ??
          'Ocurrió un error inesperado (código ${response.statusCode})';
      throw ApiException(mensaje, statusCode: response.statusCode);
    }

    return decoded;
  }
}